# The Big Mo - Professional Moving Services

This is the React + Tailwind CSS project for The Big Mo moving company.

## How to run locally

1. Clone the repo
2. Run `npm install`
3. Run `npm run dev`
4. Open `http://localhost:3000` in your browser

## How to deploy on Vercel

1. Connect your GitHub repo to Vercel
2. Import this project
3. Deploy

Contact Mo Obigmo for questions.